package Pages.Login;

import Aplicacao_WEB.Login;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {

    static WebDriver driver;
    public LoginPage(WebDriver driver){
        LoginPage.driver = driver;
    }

    public void verificarOPreenchimentoDoEmail(){
        WebElement email = driver.findElement(By.id("#email"));
        email.sendKeys("freitas.rayssaa@gmail.com");
    }
    public void verificarOPreenchimentoDaSenha(){
        WebElement senha = driver.findElement(By.id("#passwd"));
        senha.sendKeys("12345");
    }
    public void validarSingIn(){
        WebElement singIn = driver.findElement(By.id("submitLogin"));
        singIn.click();
    }
    public void validarOAcesso(){
        WebElement email = driver.findElement(By.id("#email"));
        email.sendKeys("freitas.rayssaa@gmail.com");
        WebElement senha = driver.findElement(By.id("#passwd"));
        senha.sendKeys("12345");
        WebElement singIn = driver.findElement(By.id("#submitLogin"));
        singIn.click();
    }

}
