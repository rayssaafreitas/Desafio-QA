package Pages.Carrinho;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class FreteCarrinhoPage {
    static WebDriver driver;

    public FreteCarrinhoPage (WebDriver driver){
        Pages.Frete.FreteCarrinhoPage.driver = driver;
    }
    public void elementoCursosXpath(){

    }
    public void verificarVisualizarFreteNoCarrinho(){

        WebElement FreteNoCarrinho = driver.findElement(By.cssSelector("i[ajax_cart_shipping_cost']"));
        FreteNoCarrinho.click();

    }
}
