ppackage Aplicacao_WEB;


import Pages.Contato.HomePage;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

public class Home {

    static WebDriver driver;
    static Aplicacao_WEB.Contato HomePage;

    @Before
    public void setHomePage(){
        System.setProperty("webdriver.chrome.driver","C:\\Users\\rmsantos\\IdeaProjects\\Desafio-QA-Stone-Vitta\\src\\test\\resources\\driver\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("http://automationpractice.com/index.php?");

        homePage = new HomePage(driver);
    }
    @Test
    public void visualizarPopular(){
        homePage.visualizarPopular();
    }

    @Test
    public void visualizarBestSellers(){
        homePage.visualizarBestSellers();
    }
}
