package Pages.Home;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {
    static WebDriver driver;

    public HomePage(WebDriver driver){
        HomePage.driver = driver;
    }

    public void verificarAcessoAoSiteDaMyStore(){
    }
    public void validarAsFuncionalidadesDoSiteDaMyStore(){

    }
    public void visualizarPopular(){
        WebElement popular = driver.findElement(By.cssSelector("a[class='#homefeatured']"));
        popular.click();
    }
    public void visualizarBestSellers(){
        WebElement best = driver.findElement(By.cssSelector("a[class='#blockbestsellers']"));
        best.click();
    }
}
