package Aplicacao_WEB;


import Pages.Contato.ContatoPage;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

public class Contato {

    static WebDriver driver;
    static Contato ContatoPage;

    @Before
    public void setContatoPage(){
        System.setProperty("webdriver.chrome.driver","C:\\Users\\rmsantos\\IdeaProjects\\Desafio-QA-Stone-Vitta\\src\\test\\resources\\driver\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("http://automationpractice.com/index.php?");

        contatoPage = new ContatoPage(driver);
    }
    @Test
    public void preencherContato(){ contatoPage.preencherContato();
    }

}
