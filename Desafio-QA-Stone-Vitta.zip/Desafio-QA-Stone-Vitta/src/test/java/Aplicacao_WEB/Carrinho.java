package Aplicacao_WEB;

import Pages.Carrinho.FreteCarrinhoPage;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

public class Carrinho {

    static WebDriver driver;
    static Aplicacao_WEB.Contato FreteCarrinhoPage;

    @Before
    public void setFreteCarrinhoPage(){
        System.setProperty("webdriver.chrome.driver","C:\\Users\\rmsantos\\IdeaProjects\\Desafio-QA-Stone-Vitta\\src\\test\\resources\\driver\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("http://automationpractice.com/index.php?");

        carrinhoPage = new FreteCarrinhoPage(driver);
    }
    @Test
    public void test verificarVisualizarFreteNoCarrinhoo(){
        FreteCarrinhoPage.verificarVisualizarFreteNoCarrinho();
    }
}
