package Pages.Contato;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ContatoPage {

    static WebDriver driver;


    public ContatoPage(WebDriver driver){
        ContatoPage.driver = driver;
    }
    public void preencherContato(){
        WebElement id_Contact = driver.findElement(By.id("#id_contact"));
        id_Contact.sendKeys("2");

        WebElement email = driver.findElement(By.id("#email"));
        email.sendKeys("teste@gmail.com");

        WebElement message = driver.findElement(By.id("#message"));
        message.sendKeys("testando contato");

        WebElement submit = driver.findElement(By.id("#submitmessage"));
        submit.click();

    }

}